function fillShape(img)

end