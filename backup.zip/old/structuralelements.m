se = strel('disk',5,0);
se