function drawEcoli (number)
%% Draws Ellipses representing ecoli
% Will do so randomly. Randomizes around a number of ecoli
%%
for k(1:numer)
    x=random(Poisson, A)
    y==random(Poisson, A)
    drawEllipse(50,50,8,30,80);
